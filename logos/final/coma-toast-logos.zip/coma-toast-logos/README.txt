COMA TOAST - official logo files (v1)

Five marks: plain, saint, little-devil, heaven-sent, raising-hell.
Each comes in black and white ink. The cut-outs (eyes, mouth, gaps between parts) are
transparent, so the shirt color shows through.

png/  6000 x 6000 px, transparent background, tagged 300 dpi (20 x 20 in at print size).
      The mark sits centered with some empty space around it; crop as needed.
svg/  Vector files. They scale to any size with no loss in quality.
      The cut-outs are built with SVG masks. Most design tools open these fine, but some
      embroidery or vinyl-cutting software needs plain outlines. Ask for converted files if so.
